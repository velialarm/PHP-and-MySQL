<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<?php
$number = 5;
if (number % 2 == 0) {
    echo "This number is even.";
} else {
    echo "This number is odd.";
}
?>
</body>
</html>

