<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<?php
$number1 = 5;
$number2 = 6;
if ($number1 > $number2) {
    echo "Number one is bigger than number two";
} else if ($number1 < $number2) {
    echo "Number two is bigger than number one";
} else {
    echo "Number one is equal to number two";
}
?>
</body>
</html>

