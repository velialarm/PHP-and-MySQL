<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<?php
//function declaration (the function asks for 2 parameters)
function displayFirstAndLastName($first = 'Svetlin', $last = 'Nakov')
{
    echo "<p>My first name is <strong>$first</strong>" .
        " and my last name is <strong>$last</strong></p>";
}

//call the function parsing two strings
displayFirstAndLastName("Mario", "Peshev");
displayFirstAndLastName();
 //my first name is John and my last name is Doe
?>
</body>
</html>

