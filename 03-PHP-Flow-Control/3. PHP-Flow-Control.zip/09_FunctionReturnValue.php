<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<?php

function powGivenNumber($num, $powNum)
{
    //$i = 0;
    for ($i = 0; $i < $powNum; $i += 1) {
        $num *= $num;
    }
    return $num;
}

echo powGivenNumber(4, 2);
// outputs '16'.

?>
</body>
</html>

