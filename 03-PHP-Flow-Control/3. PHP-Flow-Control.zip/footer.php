
<footer>
    <p>&copy; 2013-2014 - Software University. All Rights Reserved.</p>
</footer>
</body>
</html>