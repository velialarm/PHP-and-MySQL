<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<?php
$array = array();

$array[] = 1;
$array[] = 2;
$array[] = 3;
$array[] = 4;
$array[] = 5;
echo "<p>" . $array[0] . "</p>";
echo "<p>" . $array[1] . "</p>";
echo "<p>" . $array[2] . "</p>";
echo "<p>" . $array[3] . "</p>";
echo "<p>" . $array[4] . "</p>";
?>
</body>
</html>

