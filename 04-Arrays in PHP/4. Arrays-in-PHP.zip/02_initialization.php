<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<dl>
    <?php

    $array = array(
        'name' => 'Software University',
        'raiting' => '100',
        'students' => '1000000'
    );
    echo "<dt> University name </dt>";
    echo "<dd>" . $array['name'] . " </dd>";
    echo "<dt>Raiting </dt>";
    echo "<dd>" . $array['raiting'] . " </dd>";
    echo "<dt> Number of Studnts </dt>";
    echo "<dd>" . $array['students'] . " </dd>";
    echo "</tr>";


    ?>
</dl>
</table>
</body>
</html>

