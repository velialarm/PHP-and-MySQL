<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>

<?php

$array = array(
    'name' => 'Software University',
    'raiting' => '100',
    'students' => '1000000'
);
echo "<p><strong>var_dump() </strong></p>";
echo "<p>";
var_dump($array);
echo "</p>";
echo "<hr/>";
echo "<p><strong>print_r() </strong></p>";
echo "<p>";
print_r($array);
echo "</p>";
?>

</body>
</html>

