<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>

<?php

$array = array();
$array[] = "green";
$array[1] = "purple";
$array[] = "yellow";
echo " <strong>All elements</strong><br/>";
print_r($array);
echo "<p><strong>Array Size: " . count($array) . "</strong></p>";
echo "<hr />";

echo "<br/><strong>All elements after remove element in index 1</strong><br/>";
unset($array[1]);
print_r($array);
echo "<p><strong>Array Size: " . count($array) . "</strong></p>";


?>

</body>
</html>

