<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>

<?php

$array = array();
for($i = 0; $i < 10; $i++){
    $array[] = $i;
}

for($i = 0; $i < 10; $i++){
    $array[] = $i;
}
for($i = 0; $i < 10; $i++){
    echo "<p>" . $array[$i] . "</p>";
}
?>

</body>
</html>

