<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<table border="1">
    <tr>
        <th>Name</th>
        <th>Raiting</th>
        <th>Number of Students</th>
    </tr>
    <?php
    $array = array(
        'name' => 'Software University',
        'raiting' => '100',
        'students' => '1000000'
    );

    echo "<tr>";
    foreach ($array as $curr) {
        echo "<td>$curr</td>";
    }
    echo "</tr>";
    ?>
</table>
</body>
</html>

