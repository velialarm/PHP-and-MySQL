<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<?php
$array = array(
    "green", "yellow", 'blue');

$other = array(
    "purple", "grey");

$allTogether = array_merge($array, $other);
print_r($allTogether);
?>

</body>
</html>

