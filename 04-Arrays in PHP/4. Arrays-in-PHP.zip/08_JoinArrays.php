<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<?php
$array = array(
    "Pesho", "Gosho", 'Ivan', "Petko", "Evlogii");
$joined = implode(", ",$array);
echo "<strong>$joined </strong>"
?>

</body>
</html>

