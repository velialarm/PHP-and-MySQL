<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<?php
$array = array(
    "Pesho", "Gosho", 'Ivan', "Petko", "Evlogii");
sort($array);

echo "<p>";
echo "<strong>Sorted array:</strong>";
echo implode(", ", $array);
echo "</p>";
echo "<hr />";
shuffle($array);
echo "<p>";
echo "<strong>Shuffled array:</strong>";
echo implode(", ", $array);
echo "</p>";
?>
</body>
</html>

