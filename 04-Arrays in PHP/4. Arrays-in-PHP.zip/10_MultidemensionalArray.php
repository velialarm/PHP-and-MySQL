<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<table border="1">
    <tr>
        <th>Name</th>
        <th>Raiting</th>
        <th>Number of Students</th>
    </tr>
    <?php
    $allUni = array(
        array(
        'name' => 'Software University',
        'raiting' => '100',
        'students' => '1 000 000'),
        array(
            'name' =>"Technical University",
            'raiting' => '90',
            'students' => '12 000') ,
        array(
            'name' =>"Sv. Kliment Ohridski",
            'raiting' => '80',
            'students' => '30 000') ,

    );
    foreach ($allUni as $currUni) {
        echo "<tr>";
          foreach($currUni as $current){
              echo "<td>$current</td>";
          }
        echo "</tr>";
    }
    ?>
</table>
</body>
</html>

