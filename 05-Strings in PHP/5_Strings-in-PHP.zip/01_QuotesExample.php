<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
    <style>
        p {
            font-size: 35px;
        }
    </style>
</head>
<body>
<?php
$myCourse = "I'm \$ man.";
echo "<p> $myCourse</p>"
?>



</body>
</html>

