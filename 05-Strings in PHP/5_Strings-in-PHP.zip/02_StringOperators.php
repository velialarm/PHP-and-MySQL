<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
    <style>
        p {
            font-size: 35px;
        }
    </style>
</head>
<body>
<?php
$homeTown = "Madan";
$currentTown = "Sofia";
$homeTownDescription = "<p>My home town is " . $homeTown . "<br />";
$homeTownDescription .= "But now I am in " . $currentTown . "</p>";
echo $homeTownDescription;
?>
</body>
</html>

