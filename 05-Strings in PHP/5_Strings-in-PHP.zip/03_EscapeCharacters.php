<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
    <style>
        p {
            font-size: 35px;
        }
    </style>
</head>
<body>
<?php
$myCourse = "<p style=\"font-size:30px;\"> I'm  <strong>\$</strong> man." .
    '</p>';
echo $myCourse;
?>

</body>
</html>

