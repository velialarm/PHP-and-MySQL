<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
    <style>
        p {
            font-size: 35px;
        }
    </style>
</head>
<body>
<?php
$longestEnglishWord = "pneumonoultramicroscopicsilicovolcanoconiosis";
echo "<p>The longest English word is $longestEnglishWord. The word length is " .
    strlen($longestEnglishWord) . ".</p>";
echo ""
?>
</body>
</html>

