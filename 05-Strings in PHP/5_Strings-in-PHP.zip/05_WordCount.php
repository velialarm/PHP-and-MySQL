<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
    <style>
        p {
            font-size: 35px;
        }
    </style>
</head>
<body>
<?php
$countrys = "Bulgaria, Brazil, Italy, USA, Germany";
echo "<p>" . $countrys . "<br /></p>";
echo "<p>Previus string contains " . str_word_count($countrys) . " countries.</p>";
?>
</body>
</html>

