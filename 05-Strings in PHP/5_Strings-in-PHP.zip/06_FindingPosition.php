<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
    <style>
        p {
            font-size: 35px;
        }
    </style>
</head>
<body>
<?php
$countrys = "Brazil, Italy, Bulgaria, USA, Germany";
$bulgaria = "Bulgaria";
echo "<p>Input String:  $countrys</p>";
echo "<p>String from Bulgaria to end: " . strstr($countrys, $bulgaria) . " </p>";
echo "<p> String from Bulgaria to begin " . strstr($countrys, $bulgaria, true) . " </p>";
?>


</body>
</html>

