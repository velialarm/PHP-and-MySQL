<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
    <style>
        p {
            font-size: 35px;
        }
    </style>
</head>
<body>
<?php
$marks = "2, 2, 2, 2, 2";
$newMarks = str_replace("2", "6", $marks);

echo "<p>Nakov Marks: $marks</p>";
echo "<p>Nakov marks after hack university system: $newMarks</p>";
?>



</body>
</html>

