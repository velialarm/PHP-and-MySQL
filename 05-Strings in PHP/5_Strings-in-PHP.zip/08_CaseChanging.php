<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
    <style>
        p {
            font-size: 35px;
        }
    </style>
</head>
<body>
<?php
$name = "SoFtWaRe UnIvErSiTy";

echo "<p>Original: " . $name . "</p>";
echo "<p>Lower: " . strtolower($name) . "</p>";
echo "<p>Upper: ". strtoupper($name) ."</p>";
?>



</body>
</html>

