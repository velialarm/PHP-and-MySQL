<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
    <style>
        p {
            font-size: 35px;
        }
    </style>
</head>
<body>
<?php
$Presidents = "Georgi Pyrvanov;Jelio Jelev;Petyr Stoqnov;Rosen Pleveneliev;";
$presidentAsArray = explode(";", $Presidents);


echo "<p>Presidents of Bulgaria: <br/>";
foreach ($presidentAsArray as $current) {
    echo $current . "<br/>";
}
echo "</p>";

echo "<p>Previus Array as String: " . implode($presidentAsArray) . "<br /></p>";
?>


</body>
</html>

