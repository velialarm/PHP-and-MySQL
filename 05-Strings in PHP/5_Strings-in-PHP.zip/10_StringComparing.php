<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
    <style>
        p {
            font-size: 35px;
        }
    </style>
</head>
<body>
<?php
$fName = "Nakov";
$fNameSmall = "nakov";
echo "<p> First String: $fName</p>";
echo "<p> Second String: $fNameSmall</p>";
echo "<p>Case insensitive comparing: ";
echo strcasecmp($fName, $fNameSmall) . "</p>";
echo "<p>Case sensitive comparing: ";
echo strcmp($fName, $fNameSmall) . "</p>";
?>


</body>
</html>

