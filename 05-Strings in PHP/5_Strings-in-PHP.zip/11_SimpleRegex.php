<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
    <style>
        p {
            font-size: 35px;
        }
    </style>
</head>
<body>
<?php


$emailaddress = 'test@gmail.com';
echo "<p>Input email: $emailaddress</p>";
isValidEmail($emailaddress);

$secondEmail = "asdf@asdf";
echo "<p>Input email: $secondEmail</p>";
isValidEmail($secondEmail);

function isValidEmail($inputEmail){
    $pattern = '/^([a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})$/';
    if (preg_match($pattern, $inputEmail) === 1){
        echo "<p>Email is valid</p>";
    } else {
        echo "<p>Email is not valid</p>";
    }
}
?>
</body>
</html>

