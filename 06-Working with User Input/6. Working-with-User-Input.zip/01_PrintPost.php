<?php
if (isset($_POST['name'])) {
    $userName =  $_POST['name'];
    echo "Name: " . $userName . "<br/>";
    $email =  $_POST['email'];
    echo "Email: " . $email;
}
else{
    echo '
<form action="01_PrintPost.php" method="post">
    Name: <input type="text" name="name"><br />
    E-mail: <input type="text" name="email"><br />
    <input type="submit">
</form>';
}
?>
