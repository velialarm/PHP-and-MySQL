<?php
if (isset($_GET['name'])) {
    $userName =  $_GET['name'];
    echo "Name: " . $userName . "<br/>";
    $email =  $_GET['email'];
    echo "Email: " . $email;
}
else{
    echo '
<form action="02_Get.php" method="get">
    Name: <input type="text" name="name"><br />
    E-mail: <input type="text" name="email"><br />
    <input type="submit">
</form>';
}
?>
