<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
    <style>
        p{
            font-size:20px;
        }
    </style>
</head>
<body>
<h1>What is a Computer file</h1>

<p>
    <?php
    $content = file_get_contents("computerFile.txt");
    echo $content;
    ?>
</p>

</body>
</html>