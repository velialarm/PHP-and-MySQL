<?php
$dblink = mysql_connect("localhost", "root", "");

if(mysql_select_db("country", $dblink)){
    echo "Connected";
}
else{
    echo "Error";
}
?>