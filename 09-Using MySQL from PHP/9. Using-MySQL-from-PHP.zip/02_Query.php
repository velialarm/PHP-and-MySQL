<?php
$dblink = mysql_connect("localhost", "root", "");

if(!mysql_select_db("country", $dblink)){
    echo "Error";
}
$query = "select * from city";
$result = mysql_query($query, $dblink);
if (!$result) {
    echo 'Error: ' . mysql_error() . "\n";
    echo "Query: " . $query;
}
while ($currentRow = mysql_fetch_row($result)) {
    echo $currentRow[0] . "\n";
    echo $currentRow[1] . "\n";
}
?>