<?php
$dblink = mysql_connect("localhost", "root", "");

if(!mysql_select_db("country", $dblink)){
    echo "Error";
}
$query = "select id, name from city";
$result = mysql_query($query, $dblink);
if (!$result) {
    echo 'Error: ' . mysql_error() . "\n";
    echo "Query: " . $query;
}
$row = mysql_fetch_assoc($result);
print_r($row);
if ($row){
    echo "Id: ".$row['ID'] . "\n";
    echo "Name: ".$row['Name']. "\n";
}

?>