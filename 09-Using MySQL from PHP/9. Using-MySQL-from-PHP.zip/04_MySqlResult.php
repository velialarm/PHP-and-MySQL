<?php
$dblink = mysql_connect("localhost", "root", "");

if(!mysql_select_db("country", $dblink)){
    echo "Error";
}
$query = "select count(*) from city";
$result = mysql_query($query, $dblink);
if (!$result) {
    echo 'Error: ' . mysql_error() . "\n";
    echo "Query: " . $query;
}
echo mysql_result($result, 0, 0);


?>