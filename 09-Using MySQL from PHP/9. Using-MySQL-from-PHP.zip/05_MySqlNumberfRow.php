<?php
$dblink = mysql_connect("localhost", "root", "");

if(!mysql_select_db("country", $dblink)){
    echo "Error";
}
$query = "select id, name from people";
$result = mysql_query($query, $dblink);
if (!$result) {
    echo 'Error: ' . mysql_error() . "\n";
    echo "Query: " . $query;
}
$count = mysql_num_rows($result);
echo $count;

?>