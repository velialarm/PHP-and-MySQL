<?php
$dblink = mysql_connect("localhost", "root", "");

if(!mysql_select_db("country", $dblink)){
    echo "Error";
}
//$query = "select id, name from people";
//$result = mysql_query($query, $dblink);
//if (!$result) {
//    echo 'Error: ' . mysql_error() . "\n";
//    echo "Query: " . $query;
//}
mysql_query ('insert into City (Name, Population) values ("Kaspichan", "11111")', $dblink);
echo mysql_insert_id();


?>