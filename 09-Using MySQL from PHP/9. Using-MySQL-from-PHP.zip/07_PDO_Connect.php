<?php
try{
    $bdd = new PDO('mysql:host=localhost;dbname=country', 'root', '');
    echo 'Connected to database';
}
catch(PDOException $e) {
    echo $e->getMessage();
}
?>