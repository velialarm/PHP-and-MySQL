<?php
try{
    $dbh = new PDO('mysql:host=localhost;dbname=country', 'root', '');
    echo 'Connected to database';
}
catch(PDOException $e) {
    echo $e->getMessage();
}
//Define the query
$sql = "select * from city";
//query () returns the result
$result = $dbh->prepare($sql);
$result->execute();
//fetch() returns the first row
$row = $result->fetch();
print $row['Name'] . ' - '. $row['Population'];


//////

?>