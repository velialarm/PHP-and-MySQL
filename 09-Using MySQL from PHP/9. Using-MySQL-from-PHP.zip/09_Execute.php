<?php
try{
    $dbh = new PDO('mysql:host=localhost;dbname=country', 'root', '');
    echo 'Connected to database';
}
catch(PDOException $e) {
    echo $e->getMessage();
}


$sql = 'INSERT INTO city(name, Population) VALUES("Kaspichan", "121345")';
$dbh->exec($sql);

//Get the ID of the last inserted row
$id = $dbh->lastInsertId();
echo $id;

//////

?>