<?php
try{
    $dbh = new PDO('mysql:host=localhost;dbname=country', 'root', '');
    echo 'Connected to database';
}
catch(PDOException $e) {
    echo $e->getMessage();
}

//Define the query
//$sql = "UPDATE city SET Name = :new	Where Name = :old";
$sql = 'UPDAte City SET Name = :new
WHere Name = :old';
//Prepare the statement
$statement = $dbh->prepare($sql);

//Bind the parameters
$old = 'Kaspichan';
$new = 'Karnobat';
$statement->bindParam(':old', $old, PDO::PARAM_STR);
$statement->bindParam(':new', $new, PDO::PARAM_STR);

//Execute
if($statement->execute())
    echo "Ready";
?>