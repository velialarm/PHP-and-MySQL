<?php
try{
    $dbh = new PDO('mysql:host=localhost;dbname=country', 'root', '');
    echo 'Connected to database';
}
catch(PDOException $e) {
    echo $e->getMessage();
}

//Define the query
//$sql = "UPDATE city SET Name = :new	Where Name = :old";
//Define the query
$sql = "Delete from City Where Name = :city";

//Prepare the statement
$statement = $dbh->prepare($sql);

//Bind the parameters
$city = 'Karnobat';
$statement->bindParam(':city', $type, PDO::PARAM_STR);

//Execute
if($statement->execute())
    echo "Ready";
?>