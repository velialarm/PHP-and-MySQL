<?php
try{
    $dbh = new PDO('mysql:host=localhost;dbname=country', 'root', '');
    echo 'Connected to database' . "\n";
}
catch(PDOException $e) {
    echo $e->getMessage();
}

//Define the query
$sql = "SELECT Name, Population FROM City WHERE Id = :id";
//Prepare the statement
$statement = $dbh->prepare($sql);
//Bind the parameters
$id = 300;
$statement->bindParam(':id', $id, PDO::PARAM_INT);
//Execute the statement
$statement->execute();
//Process the result
$row = $statement->fetch(PDO::FETCH_ASSOC);
echo $row['Name']." - ".$row['Population'];

?>