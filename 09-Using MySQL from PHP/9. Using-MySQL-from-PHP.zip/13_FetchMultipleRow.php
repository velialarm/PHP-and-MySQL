<?php
try{
    $dbh = new PDO('mysql:host=localhost;dbname=country', 'root', '');
    echo 'Connected to database';
}
catch(PDOException $e) {
    echo $e->getMessage();
}

//Define the query
$sql = "SELECT Name, Population FROM CITY";
//Prepare the statement

$statement = $dbh->prepare($sql);

//Execute the statement
$statement->execute();

//Process the result
$result = $statement->fetchAll(PDO::FETCH_ASSOC);
foreach ($result as $row) {
    echo $row['Name'] . ' - ' 	. $row['Population'] . "\n";
}

//Execute
if($statement->execute())
    echo "Ready";
?>