<?php
$mysqli = new mysqli("localhost", "root", "", "country");
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" .
        $mysqli->connect_errno . ") " .
        $mysqli->connect_error;
}
$mysqli->real_query("SELECT name FROM City ORDER BY name ASC");
$res = $mysqli->use_result();

echo "Result set order...\n";
while ($row = $res->fetch_assoc()) {
    echo " Name = " . $row['name'] . "\n";
}
    ?>