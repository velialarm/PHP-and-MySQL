<?php
$mysqli = new mysqli("localhost", "root", "", "country");
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" .
        $mysqli->connect_errno . ") " .
        $mysqli->connect_error;
}
$sql='SELECT Name, Population FROM City where Population > 1000000';

$rs=$mysqli->query($sql);

if($rs === false) {
    trigger_error('Wrong SQL: ' . $sql . ' Error: ' . $conn->error, E_USER_ERROR);
} else {
    echo $rs->num_rows;
}

?>