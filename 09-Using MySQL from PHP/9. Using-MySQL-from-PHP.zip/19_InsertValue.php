<?php
$mysqli = new mysqli("localhost", "root", "", "country");
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" .
        $mysqli->connect_errno . ") " .
        $mysqli->connect_error;
}
$value="'" . $mysqli->real_escape_string('Kaspichan') . "'";

$sql="INSERT INTO City (name, population) VALUES ($value,10)";

if($mysqli->query($sql) === false) {
    trigger_error('Wrong SQL: ' . $sql . ' Error: ' . $mysqli->error, E_USER_ERROR);
} else {
    $last_inserted_id = $mysqli->insert_id;
    $affected_rows = $mysqli->affected_rows;
    echo $last_inserted_id;
    echo $affected_rows;
}

?>