<?php
$mysqli = new mysqli("localhost", "root", "", "country");
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" .
        $mysqli->connect_errno . ") " .
        $mysqli->connect_error;
}
$name="'" . $mysqli->real_escape_string('New City') . "'";

$sql="UPDATE city SET name=$name, Population=1 WHERE id=111";

if($mysqli->query($sql) === false) {
    trigger_error('Wrong SQL: ' . $sql . ' Error: ' . $conn->error, E_USER_ERROR);
} else {
    $affected_rows = $mysqli->affected_rows;
    echo $affected_rows;
}


?>