<?php
$mysqli = new mysqli("localhost", "root", "", "country");
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" .
        $mysqli->connect_errno . ") " .
        $mysqli->connect_error;
}
$sql="DELETE FROM city WHERE id=1111";

if($mysqli->query($sql) === false) {
    trigger_error('Wrong SQL: ' . $sql . ' Error: ' . $conn->error, E_USER_ERROR);
} else {
    $affected_rows = $mysqli->affected_rows;
    echo $affected_rows;
}



?>