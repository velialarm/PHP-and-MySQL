<!DOCTYPE>
<html>
    <head>
        <title>01_QueryString</title>
    <body>

        <form method="get">
            <input type="text" name="text"/>
            <input type="submit" name="submitted"/>
        </form>

        <?php
            var_dump($_SERVER['QUERY_STRING']);
        ?>

    </body>
</html>
