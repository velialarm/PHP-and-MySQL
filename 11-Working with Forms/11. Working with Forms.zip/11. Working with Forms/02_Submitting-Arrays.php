<!DOCTYPE html>
<html>
    <head>
        <title>02_Submitting-Arrays</title>
        <style>
            body{
                font-size: 2em;
            }
            select {
                width: 200px;
                font-size: 1.0em;
            }
            #submit-button{
                height:40px;
                width: 200px;
            }
        </style>
    </head>
    <body>
        <form method="post" action="02_Submitting-Arrays.php">
            <select name="people[]" multiple="multiple">
                <option value="Mario">Mario</option>
                <option value="Svetlin">Svetlin</option>
                <option value="Teodor">Teodor</option>
            </select>
            <div>
                <input type="submit" value="submit" id="submit-button" name="submit"/>
            </div>
        </form>
    </body>
</html>

<?php
    if (isset($_POST['people'])) {
        foreach ($_POST['people'] as $person) {
            echo $person . '</br>';
        }
    }