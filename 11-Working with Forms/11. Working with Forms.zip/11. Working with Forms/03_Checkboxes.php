<!DOCTYPE html>
<html>
    <head>
        <title>03_Checkboxes</title>
    </head>
    <body>
        <form method="post" action="03_Checkboxes.php" name="checkboxes">
            <input type="checkbox" name="first" />
            <span>Please, select me, I am a checkbox!</span>
            <input type="checkbox" name="second" />
            <span>Don't select me for a cool demo. I won't be passed</span>
            <br>
            <input type="submit" name="submit"/>
        </form>
    </body>
</html>
<?php
    if ($_POST) {
        var_dump($_POST);
    }