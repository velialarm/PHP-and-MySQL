<!DOCTYPE html>
<html>
    <head>
        <title>04_HiddenFields</title>
    </head>
    <body>

        <form action="04_HiddenFields.php" method="post"> 
            Name:<input type="text" name="name" /></br> 
            <input type="hidden" name="hiddenNinja" value="A ninja input field is hiding in the bushes."/> 
            <input type="submit" value="click" name="in">
        </form>

        <?php
            if (isset($_POST['in'])) {
                echo 'My name is ' . $_POST['name'] . '</br>';
                echo $_POST['hiddenNinja'] . '</br></br>';
                var_dump($_POST);
            }
        ?>

    </body>
</html>