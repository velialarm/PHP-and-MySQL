<!DOCTYPE html>
<html>
    <head>
        <title>05_InputTypes</title>
    </head>
    <body>
        <form method="post" action="05_InputTypes.php" name="input-types">
            <p>Username:</p>
            <input type="text" name="username"/>
            <p>Password:</p>
            <input type="password" name="password"/>
            <p>Email:</p>
            <input type="email" name="email"/>
            <p>Gender:</p>
            Male:<input type="radio" name="gender"/>Female:<input type="radio" name="gender"/>
            <p>Birth date:</p>
            <input type="date" name="birthdate">
            <p>Favorite color?</p>
            <input type="color" name="color">
            <p><input type="submit" name="submit"/></p>
        </form>
    </body>
</html>
<?php
    if ($_POST) {
        var_dump($_POST);
    }