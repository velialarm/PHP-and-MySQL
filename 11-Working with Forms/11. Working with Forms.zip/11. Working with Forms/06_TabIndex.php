<!DOCTYPE html>
<html>
    <head>
        <title>06_TabIndex</title>
    </head>
    <body>
        <form method="post" name="tab-index" action="06_TabIndex.php">
            <p>Tab index 1</p>
            <input type="text" tabindex="1"/>
            <p>Tab index 4</p>
            <input type="text" tabindex="4"/>
            <p>Tab index 3</p>
            <input type="text" tabindex="3"/>
            <p>Tab index 2</p>
            <input type="text" tabindex="2"/>
            <p><input type="submit" value="I am a submit button. LOL."/></p>
        </form>
    </body>    
</html>