<!DOCTYPE html>
<html>
    <head>
        <title>07_Redirecting the user</title>
    </head>
    <body>
        <form method="post" action="07_RedirectingTheUser.php" >
            <input type="submit" value="I am actually an input with type submit. Click to go to softuni.bg" name="in"/>
        </form>
        <?php
            if (isset($_POST['in'])) {
                $url = "https://softuni.bg";
                header('Location: ' . $url);
            }
        ?>
    </body>
</head>
</html>