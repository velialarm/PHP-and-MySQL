<html>
	<head>
	</head>
	<body>
		<?php
			function checkNum($number) {
		  		if($number>1) {
			    	throw new Exception("Value must be 1 or below", 999);
			  	}
			  	return true;
			}
			try {
				checkNum(2);
			} catch (Exception $e) {
				echo $e->getMessage()."<br/>"." code: ".$e->getCode();
			}
		?>
	</body>
</html>