<html>
	<head>
	</head>
	<body>
		<?php
			$a = 5;
			$b = 0;
			try {
				if ($b == 0) {
					throw new Exception("You cannot divide by zero");
				} else {
					$i = $a/$b;
					echo $i;
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		?>
	</body>
</html>