<html>
	<head>
	</head>
	<body>
		<?php
			try {
				$name = 1;
				$email = 1;
				$saved = 0;
				if (!$name) {
					throw new Exception('No name supplied', 1001);
				}
				if (!$email) {
					throw new Exception ('No email supplied', 1002);
				}
				if (!$saved) {
					throw new Exception ('Unable to save!', 1003);
				}
			} catch (Exception $e) {
				$code = $e->getCode();
				if ($code > 1000 && $code < 1003) {
					echo "Please fill in all the data"."<br/>";
					echo $e->getMessage()." / code: ".$e->getCode();
				}
				elseif ($code == 1003) {
					echo "Database error or unescaped symbols!"."<br/>";
					echo $e->getMessage()." / code: ".$e->getCode();
				}
				else {
					throw $e; // re-throw the exception!
				}
			}		
		?>
	</body>
</html>