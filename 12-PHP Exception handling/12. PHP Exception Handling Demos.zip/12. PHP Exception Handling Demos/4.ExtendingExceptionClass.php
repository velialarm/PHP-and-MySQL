<html>
	<head>
	</head>
	<body>
		<?php
			class EMyException extends Exception {
				public function __construct() {
					parent::__construct('Ooops!', 101);
				}
			}
			
			try {
				$a = 2;
				$b = 3;
				$c = $a * $b;
				Throw new EMyException();
			} catch (EMyException $e) {
			echo "My exception was raised!"."<br/>";
					echo $e->getMessage()." / code: ".$e->getCode();
			}
		?>
	</body>
</html>