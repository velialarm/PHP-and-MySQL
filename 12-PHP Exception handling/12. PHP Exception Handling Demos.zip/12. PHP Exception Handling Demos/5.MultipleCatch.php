<html>
	<head>
	</head>
	<body>
		<?php
			class EMyException extends Exception {
				public function __construct() {
					parent::__construct('Ooops!', 101);
				}
			}
			
			try {
				$a = 5;
				$b = 2;
				$i = $a/$b;
				throw new EMyException();
			} catch (EMyException $e) {
				echo 'My exception was raised';
			} catch (Exception $e) {
				echo 'You cannot divide by zero';
			}		
		?>
	</body>
</html>