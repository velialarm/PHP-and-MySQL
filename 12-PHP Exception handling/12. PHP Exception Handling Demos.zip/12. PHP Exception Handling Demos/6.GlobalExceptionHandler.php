<html>
	<head>
	</head>
	<body>
		<?php
			function ex_handler ($exception) {
				echo "Uncaught: ".$exception->getMessage();
			}
			set_exception_handler('ex_handler');
			throw new Exception ('boom');
			echo 'this line is not executed';
		?>
	</body>
</html>