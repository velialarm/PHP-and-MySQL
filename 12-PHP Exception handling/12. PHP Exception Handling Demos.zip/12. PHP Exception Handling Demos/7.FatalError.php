<html>
	<head>
	</head>
	<body>
		<?php
			$a = 2;
			$b = 3;
			multiply_two(a,b);
		?>
	</body>
</html>