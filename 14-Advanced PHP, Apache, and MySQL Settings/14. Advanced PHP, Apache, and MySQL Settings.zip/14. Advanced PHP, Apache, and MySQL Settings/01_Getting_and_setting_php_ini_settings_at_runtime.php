<?php
	// Get the runtime value of a php.ini variable
	echo ini_get("upload_max_filesize");
	// Get the value of a php.ini variable which is stored in the file
	get_cfg_var("upload_max_filesize");

	// Change the value of a php.ini variable at runtime
	ini_set("include_path", "c:/php/PEAR");
	echo ini_get("include_path");
?>