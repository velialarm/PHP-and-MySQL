<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Opening and Reading a File</title>
</head>
<body>
	<?php
		$file = fopen("text.txt", "rb");
		if($file) {
			$contents = fread($file, 56);
			echo $contents;
		} else {
			echo "Error reading file.";
		}
	?>
</body>
</html>
