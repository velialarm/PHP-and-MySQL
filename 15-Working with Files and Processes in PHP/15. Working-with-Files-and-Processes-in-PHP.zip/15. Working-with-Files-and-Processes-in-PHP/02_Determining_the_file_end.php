<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Determining the File End</title>
</head>
<body>
	<?php
		$file = fopen("text.txt", "rb");
		if($file) {
			while(!feof($file)) {
				echo fread($file, 32);
			}
		} else {
			echo "Error reading file.";
		}
	?>
</body>
</html>
