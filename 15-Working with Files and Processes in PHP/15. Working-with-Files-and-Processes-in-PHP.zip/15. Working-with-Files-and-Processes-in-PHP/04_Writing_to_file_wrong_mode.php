<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Writing to File - Wrong Mode</title>
</head>
<body>
	<?php
		$file = fopen("hello.txt", "r");
		if($file) {
			$bytes = fwrite($file, "Hello World");
			
			if($bytes > 0) {
				echo $bytes . " bytes written to \"hello.txt\".";
			}
			else {
				echo "Error writing to file.";
			}
		}
		else {
			echo "Error opening file.";
		}
	?>
</body>
</html>
