<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Reading and Writing at Once</title>
</head>
<body>
	<?php
		echo "<strong>Contents of an existing file:</strong> ";
		echo file_get_contents("text.txt");
		echo "<br /><br />";
		echo "<strong>Contents of an newly created file:</strong> ";
		
		// Ensure the file is always unique - include the current timestamp at file creation
		$fileName = "newfile" . time() . ".txt";
		file_put_contents($fileName, "This is a new file.");
		echo file_get_contents($fileName);
	?>
</body>
</html>
