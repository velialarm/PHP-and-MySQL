<?php
	$file = fopen("http://softuni.bg", "r");
	$content = "";
	while(!feof($file)) {
		$content .= fread($file, 512);
	}

	fclose($file);
	echo $content;
?>