<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Listing Files in a Directory</title>
</head>
<body>
	<?php
		foreach(glob("*.txt") as $file) {
			echo $file . ": " . filesize($file) . "<br />";
		}
	?>
</body>
</html>
