<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Opening, Reading, and Closing Directories</title>
</head>
<body>
	<?php
		// __DIR__ is a global variable pointing to the current directory
		$dir = opendir(__DIR__);
		
		// readdir() may return a result which evaluates to false. Therefore, the only
		// valid way to loop over the directory, is to use the !== operator to check if the loop has finished
		while (($entry = readdir($dir)) !== false) {
        echo $entry . "<br />";
    }
	?>
</body>
</html>
