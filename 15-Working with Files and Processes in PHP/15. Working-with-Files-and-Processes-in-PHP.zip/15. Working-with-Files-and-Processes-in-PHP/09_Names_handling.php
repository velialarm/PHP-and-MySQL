<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Names Handling</title>
</head>
<body>
	<?php
		// Note that the path does not need to be valid
		$path = "home/avatar/file.txt";
		echo "<strong>Basename:</strong> " . basename($path) . "<br />";
		echo "<strong>Dirname:</strong> " . dirname($path);
	?>
</body>
</html>
