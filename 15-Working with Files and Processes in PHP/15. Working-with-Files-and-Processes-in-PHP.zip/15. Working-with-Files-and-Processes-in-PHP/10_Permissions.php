<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Permissions</title>
</head>
<body>
	<?php
		$file = "text.txt";
		echo "<strong>File owner: </strong>" . fileowner($file) . "<br />";
		echo "<strong>File group: </strong>" . filegroup($file) . "<br />";
		
		// Show the file permissions as an octal value (it is decimal by default)
		echo "<strong>File permissions: </strong>" . substr(sprintf("%o",fileperms($file)), -4) . "<br /><br/>";
		
		echo "The file <strong>".$file."</strong> is " . (is_readable($file)? "" : " not ") . "readable.<br />";
		echo "The file <strong>".$file."</strong> is " . (is_writable($file)? "" : " not ") . "writable.<br />";
	?>
</body>
</html>
