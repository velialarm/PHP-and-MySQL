<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Executing Processes</title>
</head>
<body>
	<?php
		$list = array();
		
		// Windows - "dir"
		exec("dir", $list);
		// Linux - "ls -l"
		// exec("ls -l", $list);
		echo implode("<br />", $list);
	?>
</body>
</html>
