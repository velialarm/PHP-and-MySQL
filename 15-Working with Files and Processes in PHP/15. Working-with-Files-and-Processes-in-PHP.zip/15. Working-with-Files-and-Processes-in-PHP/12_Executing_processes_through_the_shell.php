<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Executing Processes through the Shell</title>
</head>
<body>
	<?php
		$lines = explode("\n", shell_exec("set"));
		foreach ($lines as $line) {
			// Show the path to bash
			if(preg_match("/BASH=(.*)/", $line, $chunk)) {
				echo $chunk[1];
			}
			
			// Show the path to Java
			if(preg_match("/JAVA_HOME=(.*)/", $line, $chunk)) {
				echo $chunk[1];
			}
		}
	?>
</body>
</html>
