<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Opening a Process</title>
</head>
<body>
	<?php
		$spec = array (
			0 => array ("pipe", "r"),
			1 => array ("pipe", "w"),
			2 => array ("file", "log.txt", "a"));
		$env = array ("PATH" => "/bin/bash");
		$process = proc_open("/bin/bash", $spec, $pipes, "/", $env);
		$stdIn = $pipes[0];
		$stdOut = $pipes[1];
		fwrite($stdIn, "date");
		echo fread($stdOut, 128);
		fclose($stdIn);
		fclose($stdOut);
		proc_close($process);
	?>
</body>
</html>
