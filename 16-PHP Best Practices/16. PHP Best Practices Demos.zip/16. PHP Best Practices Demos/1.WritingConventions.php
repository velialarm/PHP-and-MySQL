<html>
	<head>
	</head>
	<body>
		<?php
			$number = 10;
			echo $number, " => ", gettype($number), "</br>";
			$isEqual = true;
			echo $isEqual, " => ", gettype($isEqual), "</br>";
			$currentWord = "yes";
			echo $currentWord, " => ", gettype($currentWord), "</br>";
			define("MIN_VALUE", -2147483647);
			define("MAX_VALUE", 2147483647);
			define("ABSOLUTE_ZERO", -273.15);
			echo "constants to follow: ";
			echo MIN_VALUE, ", ", MAX_VALUE, ", ", ABSOLUTE_ZERO;
		?>
	</body>
</html>