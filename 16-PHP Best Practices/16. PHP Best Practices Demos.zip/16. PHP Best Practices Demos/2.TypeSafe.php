<html>
	<head>
	</head>
	<body>
		<?php
			$str = "2";
			$intgr = (int) $str;
			if ($str == $intgr) {
				echo "true";
			} else {
				echo "false";
			}
			echo "</br>";
			if ($str === $intgr) {
				echo "true";
			} else {
				echo "false";
			}
		?>
	</body>
</html>