<html>
	<head>
	</head>
	<body>
		<?php
			for ($i = 10000; $i > 0; $i --) {
				throw new Exception ('I Leak Memory!');
			}
		?>
	</body>
</html>