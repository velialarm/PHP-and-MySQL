<html>
	<head>
	</head>
	<body>
		<?php
			/**
			 * MyClass description
			 *
			 * @category MyClasses
			 * @package MyBaseClasses
			 * @copyright Copyright � 2008 LockSoft
			 * @license GPL
			 **/
			class MyClass extends BaseClass {
				/**
				 * Easily return the value 1
				 *
				 * Call this function with whatever parameters
				 * you want � it will always return 1
				 *
				 * @param string $name The name parameter
				 * @return int The return value
				 **/
				protected function foo ($name) {
					return 1;
				}
			}
		?>
	</body>
</html>