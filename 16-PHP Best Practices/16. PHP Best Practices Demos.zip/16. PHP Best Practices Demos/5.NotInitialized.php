<html>
	<head>
	</head>
	<body>
		<?php
			$a = true;
			$b = false;
			if ($a == $b) {
				$login = true;
			}
			echo $login
		?>
	</body>
</html>