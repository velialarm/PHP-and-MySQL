<html>
	<head>
	</head>
	<body>
		<?php
			$str = addslashes('We are studying in "Software University"!');
			echo($str);
		?>
	</body>
</html>