<html>
	<head>
	</head>
	<body>
		<?php
			$arr = [0,1,2,3,4,5,6,7,8,9];
			//slow
			for ($i = 0; $i < count($arr); $i++) {
				echo $i;
			}
			//fast
			for ($i = 0, $n = count($arr); $i<$n; ++$i) {
				echo $i;
			}
			
			echo "</br>";
			
			$world = "World";
			//slow
			echo "Hello";
			echo " ";
			echo $world;
			//fast
			echo "Hello ", $world;
		?>
	</body>
</html>