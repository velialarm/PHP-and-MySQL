<html>
	<head>
	</head>
	<body>
		<?php
			$str = "example@host.com";
			//slow
			if (preg_match("/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}/", $str)) {
				echo "regex match";
			}
			
			echo "</br>";
			
			//fast
			if (filter_var($str,FILTER_VALIDATE_EMAIL)) {
				echo "filter match";
			}
		?>
	</body>
</html>