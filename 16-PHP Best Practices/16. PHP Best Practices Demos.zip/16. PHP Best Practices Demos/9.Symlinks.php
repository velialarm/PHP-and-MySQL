<html>
	<head>
	</head>
	<body>
		<?php
			$target = '~/1.WritingConventions.php';
			$link = 'uploads';
			symlink($target, $link);
			
			echo(readlink($link));
		?>
	</body>
</html>