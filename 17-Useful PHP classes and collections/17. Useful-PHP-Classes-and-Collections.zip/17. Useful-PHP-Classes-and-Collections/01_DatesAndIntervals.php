<!DOCTYPE html>
<html>
    <head>
        <title>01_DatesAndIntervals</title>
    </head>
    <body>
	<?php
		date_default_timezone_set('Europe/Sofia');
		$now = new DateTime();
		var_dump($now);
		echo '<br>';
		$interval = new DateInterval("PT10M");
		$afterTen = $now->add($interval);
		var_dump($afterTen);
	?>
    </body>    
</html>
