<!DOCTYPE html>
<html>
    <head>
        <title>03_XMLReader</title>
    </head>
    <body>
	<?php
		$xml = new XMLReader();
		$xml->open( '03_XMLReaderData.xml' );

		while( $xml->read() ) {
		  if( 'product' === $xml->name ) {
				printf( '<hr>%3$s is a %1$s and has the value of %2$d<br>', $xml->name, $xml->getAttribute('tax'), $xml->getAttribute('name') );
				$xml->next();
			}
		}
	?>
    </body>    
</html>
