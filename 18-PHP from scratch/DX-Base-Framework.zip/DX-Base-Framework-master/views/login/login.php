<p><?php echo $login_text; ?></p>
<form method="POST">
	<p>
		Username: <input type="text" name="username" />
	</p>
	<p>
		Password: <input type="password" name="password" />
	</p>

	<input type="submit" />
</form>